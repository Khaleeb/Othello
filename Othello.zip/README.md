# Othello
### cisc260 
